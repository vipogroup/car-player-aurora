# Local Server Setup (Windows + Mobile)

1. Install Python 3.10+ from python.org (check "Add Python to PATH").
2. Open CMD/PowerShell in this folder.
3. Run: `pip install -r requirements.txt`
4. For mobile in same Wi-Fi: run `start-server-lan.bat`
5. On phone open: `http://<PC-IP>:5600` (example `http://192.168.1.50:5600`)
6. To verify correct server: `http://<PC-IP>:5600/__player_check` (must show `OK_UNBLOCKED_PLAYER_V5`).

Notes:
- PC must stay on while phone uses it.
- If phone cannot connect, allow Python/port 5600 in Windows Firewall.
